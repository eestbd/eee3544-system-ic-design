HW1 modular arithmetic and CT butterfly code

Required Verilog files:
  mod_add.v
  mod_sub.v
  mod_mul.v
  bfly_ct.v
  tb_hw1.v

Supporting files:
  golden_model.py           Python reference model and vector generator
  vectors/mod_arith.txt     Arithmetic inputs and expected results
  vectors/bfly_ct.txt       Butterfly inputs and expected results
  vectors/*_cases.csv       Case categories and selection reasons
  run_sim.do               ModelSim compile and simulation script

Run from the folder containing these files:
  vsim -c -do run_sim.do

The script creates sim_results/, regenerates the vectors with Python,
compiles the five Verilog files, and runs tb_hw1 until completion.
In the ModelSim GUI, change to this folder and enter:
  do run_sim.do

To run the testbench manually, keep vectors/ and sim_results/ present,
compile all five Verilog files, simulate tb_hw1, and use run -all.
The supplied text vectors can be used without running Python again.

Verification cases:
  mod_add, mod_sub, mod_mul: 6 provided + 20 corner + 100 random each
  bfly_ct:                  5 provided + 20 corner + 100 random
  Butterfly vectors use zeta=2580.

This archive contains code and supporting files only.
Add the required report and rename the final archive to studentID_name.zip
before submitting it to LearnUs.
